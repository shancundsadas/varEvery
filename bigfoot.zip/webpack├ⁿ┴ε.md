## 安装
### npm install webpack webpack-cli

## 翻译
### npm webpack ./index.js