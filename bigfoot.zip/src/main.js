// 创建 实例
class Bigfoot {
	constructor(options) {
		// 挂载 data 数据
		this.$data = options.data;
		for (let key in this.$data) {
			eval('this.' + key + '=  this.$data .' + key);
		}
		
		// 挂载 函数 到 $methods
		this.$methods = options.methods
		for (let key in this.$methods) {
			eval('this.' + key + '= this.$methods.' + key);
		}
		
		// 挂载 钩子函数
		this.$mounted = options.mounted
		
		// 运行 钩子 函数
		let onLoad = () => {
			if (this.$mounted) {
				this.$mounted()
			}
		}
		onLoad()
	}
}
